-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2022 at 11:07 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `akademik`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id_department` int(11) NOT NULL,
  `name_department` varbinary(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id_department`, `name_department`) VALUES
(1, 0x54656b6e696b20496e666f726d6174696b61),
(2, 0x54656b6e696b204d6573696e),
(3, 0x54656b6e696b20456c656b74726f),
(4, 0x54656b6e696b20466973696b61);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id_student` int(11) NOT NULL,
  `first_name` varchar(80) NOT NULL,
  `last_name` varchar(80) NOT NULL,
  `address` varchar(300) NOT NULL,
  `department_id_department` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id_student`, `first_name`, `last_name`, `address`, `department_id_department`) VALUES
(2020001, 'Ayunda', 'Novani', 'Bandung', 1),
(2020002, 'Ia', 'Nuraidah', 'Garut', 2),
(2020003, 'Nita', 'Nujabaturahman', 'Majalengka', 3),
(2020004, 'Tita', 'Widia', 'Majalengka', 1),
(2020005, 'Rena', 'Nurhafilah', 'Majalengka', 2),
(2020006, 'Lathifa', 'Azzahra', 'Cirebon', 3),
(2020007, 'Maryam', 'Azzahra', 'Ciamis', 1),
(2020008, 'Siti', 'Nurhasanah', 'Jakarta', 2),
(2020009, 'Eha', 'Julaeha', 'Ciamis', 3),
(2020010, 'Ida ', 'WIdiyawati', 'Tasikmalaya', 1),
(2020011, 'Gina', 'Nurjannah', 'Jakarta', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id_department`),
  ADD UNIQUE KEY `id_UNIQUE` (`id_department`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id_student`,`department_id_department`),
  ADD UNIQUE KEY `id_student_UNIQUE` (`id_student`),
  ADD KEY `fk_student_departement_idx` (`department_id_department`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id_department` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id_student` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2020012;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `fk_student_departement` FOREIGN KEY (`department_id_department`) REFERENCES `department` (`id_department`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
