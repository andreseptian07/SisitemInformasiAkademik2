package com.itc.sisiteminformasiakademik.controller;

import com.itc.sisiteminformasiakademik.dao.DepartmentDaoImplementation;
import com.itc.sisiteminformasiakademik.dao.StudentDaoImplementation;
import com.itc.sisiteminformasiakademik.entity.Department;
import com.itc.sisiteminformasiakademik.entity.Student;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class MainController implements Initializable {

    @FXML
    private TextField addressTextField;

    @FXML
    private TableColumn<Student, String> colAddress;

    @FXML
    private TableColumn<Student, String> colFirstName;

    @FXML
    private TableColumn<Department, Integer> colIdDepartment;

    @FXML
    private TableColumn<Student, Integer> colIdStudent;

    @FXML
    private TableColumn<Student, String> colLastName;

    @FXML
    private TableColumn<Department, String> colNameDepartment;

    @FXML
    private TableColumn<Student, Department> colNameDepartmentOnStudent;

    @FXML
    private ComboBox<Department> departmentCombobox;

    @FXML
    private TextField firstNameTextField;

    @FXML
    private TextField idStudentTextField;

    @FXML
    private TextField lastNameTextField;

    @FXML
    private TextField nameDepartmentTextField;

    private ObservableList<Department> departments;
    private ObservableList<Student> students;
    private DepartmentDaoImplementation departmentDao;
    private StudentDaoImplementation studentDao;
    @FXML
    private TableView <Department> tabelViewDepartment;
    @FXML
    private TableView<Student>tabelViewStudent;

    @FXML
    void saveDepartmentOnAction(ActionEvent event) {
        if (nameDepartmentTextField.getText().trim().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Tolong Diisi Nama Department");
            alert.showAndWait();
        } else {
            Department department = new Department();
            department.setNameDepartment(nameDepartmentTextField.getText().trim());
            try {
                if (departmentDao.addData(department) == 1) {
                    departments.clear();
                    departments.addAll(departmentDao.fetchAll());
                    nameDepartmentTextField.clear();
                }
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    void saveStudentOnAction(ActionEvent event) {
        if (idStudentTextField.getText().trim().isEmpty() &&
                firstNameTextField.getText().trim().isEmpty() &&
                lastNameTextField.getText().trim().isEmpty() &&
                addressTextField.getText().trim().isEmpty() &&
                departmentCombobox.getValue() == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Tolong Semua Field Diisi");
            alert.showAndWait();
        } else {
            Student student = new Student();
            student.setIdStudent(Integer.parseInt(idStudentTextField.getText().trim()));
            student.setFirstName(firstNameTextField.getText().trim());
            student.setLastName(lastNameTextField.getText().trim());
            student.setAddress(addressTextField.getText().trim());
            student.setDepartment(departmentCombobox.getValue());
            try {
                if (studentDao.addData(student) == 1) {
                    students.clear();
                    students.addAll(studentDao.fetchAll());
                    firstNameTextField.clear();
                    lastNameTextField.clear();
                    addressTextField.clear();

                }

            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();

            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        departmentDao = new DepartmentDaoImplementation();
        studentDao = new StudentDaoImplementation();
        departments = FXCollections.observableArrayList();
        students = FXCollections.observableArrayList();

        try {
            departments.addAll(departmentDao.fetchAll());
            students.addAll(studentDao.fetchAll());
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        departmentCombobox.setItems(departments);

        tabelViewDepartment.setItems(departments);
        colIdDepartment.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getIdDepartment()).asObject());
        colNameDepartment.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNameDepartment()));

        tabelViewStudent.setItems(students);
        colIdStudent.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getIdStudent()).asObject());
        colFirstName.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFirstName()));
        colLastName.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getLastName()));
        colAddress.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAddress()));
        colNameDepartmentOnStudent.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getDepartment()));

    }
}
