package com.itc.sisiteminformasiakademik.dao;

import com.itc.sisiteminformasiakademik.entity.Department;
import com.itc.sisiteminformasiakademik.entity.Student;
import com.itc.sisiteminformasiakademik.util.DaoService;
import com.itc.sisiteminformasiakademik.util.MySQLConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentDaoImplementation implements DaoService<Student> {

    @Override
    public List<Student> fetchAll() throws SQLException, ClassNotFoundException {
        List<Student> students = new ArrayList<>();
        try (Connection connection = MySQLConnection.createConnection()) {
            String query = "SELECT s.id_student, s.first_name, s.last_name, s.address, " +
                    "s.department_id_department, d.name_department AS department_name " +
                    "FROM student s JOIN department d ON s.department_id_department  = d.id_department";
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Department department = new Department();
                        department.setIdDepartment(rs.getInt("department_id_department"));
                        department.setNameDepartment(rs.getString("department_name"));

                        Student student = new Student();
                        student.setIdStudent(rs.getInt("id_student"));
                        student.setFirstName(rs.getString("first_name"));
                        student.setLastName(rs.getString("last_name"));
                        student.setAddress(rs.getString("address"));
                        student.setDepartment(department);
                        students.add(student);

                    }
                }
            }
        }
        return students;
    }

    @Override
    public int addData(Student object) throws SQLException, ClassNotFoundException {
        int result = 0;
        try (Connection connection = MySQLConnection.createConnection()) {
            String query = "INSERT INTO student " +
                    "(id_student, first_name, last_name, address, department_id_department) " +
                    "VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setInt(1, object.getIdStudent());
                ps.setString(2, object.getFirstName());
                ps.setString(3, object.getLastName());
                ps.setString(4, object.getAddress());
                ps.setInt(5, object.getDepartment().getIdDepartment());
                if (ps.executeUpdate() != 0) {
                    connection.commit();
                    result = 1;
                } else {
                    connection.rollback();
                }
            }
        }
        return result;
    }
}
